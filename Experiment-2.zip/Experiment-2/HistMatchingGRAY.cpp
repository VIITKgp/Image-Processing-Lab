#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#define WIDTH 512
#define HEIGHT 512

using namespace std;
using namespace cv;


void histogramcalculation(Mat image, int histogram[])
{

	// initializing all intensity levels to 0
	for (int i = 0; i < 256; i++)
	{
		histogram[i] = 0;
	}

	// calculating pixel density for each intensity level
	for (int y = 0; y < image.rows; y++)
		for (int x = 0; x < image.cols; x++)
			histogram[(int)image.at<uchar>(y, x)]++;

}

void CDFhistogram(int histogram[], int CFhistogram[])
{
	CFhistogram[0] = histogram[0];

	for (int i = 1; i < 256; i++)
	{
		CFhistogram[i] = histogram[i] + CFhistogram[i - 1];
	}
}

void histogramDisplay(int histogram[], const char* name)
{
	int hist[256];
	for (int i = 0; i < 256; i++)
	{
		hist[i] = histogram[i];
	}
	// draw the histograms
	int hist_w = 512; int hist_h = 400;
	int bin_w = cvRound((double)hist_w / 256);

	Mat histImage(hist_h, hist_w, CV_8UC1, Scalar(255, 255, 255));

	// finding maximum intensity element from histogram
	int max = hist[0];
	for (int i = 1; i < 256; i++) {
		if (max < hist[i]) {
			max = hist[i];
		}
	}

	// normalizing the histogram
	for (int i = 0; i < 256; i++) {
		hist[i] = ((double)hist[i] / max) * histImage.rows;
	}

	// draw the intensity line for histogram
	for (int i = 0; i < 256; i++)
	{
		line(histImage, Point(bin_w * (i), hist_h),
			Point(bin_w * (i), hist_h - hist[i]),
			Scalar(0, 0, 0), 1, 8, 0);
	}

	// display histogram
	namedWindow(name);
	imshow(name, histImage);
}

void HistGRAY()
{
	Mat image = imread("C:/Users/Vaibhav/Desktop/lena_gray_dark.jpg", IMREAD_GRAYSCALE); //input image
	namedWindow("Original Image");
	imshow("Original Image", image);

	//Generating histogram
	int histogram[256];
	histogramcalculation(image, histogram);

	// Caluculating the size of image
	int size = image.rows * image.cols;
	float factor = 255.0 / size;

	// Calculate PDF
	float PDF[256];
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)histogram[i] / size;
	}

	// Generating cumulative frequency
	int CFhistogram[256];
	CDFhistogram(histogram, CFhistogram);

	// Scaling histogram
	int Scaledhist1[256];
	for (int i = 0; i < 256; i++)
	{
		Scaledhist1[i] = cvRound((double)CFhistogram[i] * factor);
	
	}
	histogramDisplay(histogram, "Input Histogram");


	Mat image1 = imread("C:/Users/Vaibhav/Desktop/lake.jpg", IMREAD_GRAYSCALE); //target image
	namedWindow("Target Image");
	imshow("Target Image", image1);
	
    //Generating histogram
	int histogram1[256];
	histogramcalculation(image1, histogram1);

	// Calculating PDF 
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)histogram1[i] / size;
	}

	// Generating cumulative frequency
	CDFhistogram(histogram1, CFhistogram);

	// Scaling histogram
	int Scaledhist2[256];
	for (int i = 0; i < 256; i++)
	{
		Scaledhist2[i] = cvRound((double)CFhistogram[i] * factor);
	}

	int finalhist[256];
	float x;
	int	k;
	for (int i = 0; i < 256; i++)
	{
		k = 0;
		x = 256;//keeping difference max at start
		for (int j = 0; j < 256; j++)
		{
			if(abs(Scaledhist1[i]- Scaledhist2[j])<x)
			{
				x = abs(Scaledhist1[i] - Scaledhist2[j]); //finding mapping level from target
				k = j;
			}
		}
		finalhist[i] = Scaledhist2[k]; //mapping the input histogram level to target histogram
	}
	
	int final[256];
	for (int i = 1; i < 256; i++)
		final[i] = (finalhist[i]- finalhist[i-1]); //matched histogram


	// Generating equilized image
	Mat new_image = image.clone();

	for (int y = 0; y < image.rows; y++)
		for (int x = 0; x < image.cols; x++)
			new_image.at<uchar>(y, x) = saturate_cast<uchar>(finalhist[image.at<uchar>(y, x)]); //obtaining new output image


	// Display the original Histogram
	histogramDisplay(histogram1, "Target Histogram");

	// Display equilized image
	namedWindow("Matched Image");
	imshow("Matched Image", new_image);
	imwrite("C:/Users/Vaibhav/Desktop/DIP/output exp2/matchcedlena_gray_dark.jpg",new_image);

	// Display the equilzed histogram
	histogramDisplay(final, "Matched Histogram");

	waitKey();
}


int main()
{
	HistGRAY();
	return 0;
}

