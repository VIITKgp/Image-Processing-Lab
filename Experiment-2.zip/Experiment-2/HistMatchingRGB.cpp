#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#define WIDTH 512
#define HEIGHT 512

using namespace std;
using namespace cv;


void histogramcalculation(Mat image, int histogram[],int c)
{
	// initializing all intensity levels
	for (int i = 0; i < 256; i++)
	{
		histogram[i] = 0;
	}

	// calculating pixel density for each intensity level
	for (int y = 0; y < image.rows; y++)
		for (int x = 0; x < image.cols; x++)
			histogram[(int)image.at<Vec3b>(y, x)[c]]++;

}

void CDFhistogram(int histogram[], int CFhistogram[])
{
	CFhistogram[0] = histogram[0];

	for (int i = 1; i < 256; i++)
	{
		CFhistogram[i] = histogram[i] + CFhistogram[i - 1];
	}
}

void histogramDisplay(int histogram[], const char* name)
{
	int hist[256];
	for (int i = 0; i < 256; i++)
	{
		hist[i] = histogram[i];
	}
	// creating histograms
	int hist_w = 512; int hist_h = 400;
	int bin_w = cvRound((double)hist_w / 256);

	Mat histImage(hist_h, hist_w, CV_8UC1, Scalar(255, 255, 255));

	// finding maximum intensity element from histogram
	int max = hist[0];
	for (int i = 1; i < 256; i++) {
		if (max < hist[i]) {
			max = hist[i];
		}
	}

	// normalizing the histogram
	for (int i = 0; i < 256; i++) {
		hist[i] = ((double)hist[i] / max) * histImage.rows;
	}


	// draw the intensity line for histogram
	for (int i = 0; i < 256; i++)
	{
		line(histImage, Point(bin_w * (i), hist_h),
			Point(bin_w * (i), hist_h - hist[i]),
			Scalar(0, 0, 0), 1, 8, 0);
	}

	// display histogram
	namedWindow(name);
	imshow(name, histImage);
}

void HistMatchRGB()
{
	Mat image = imread("C:/Users/Vaibhav/Desktop/4.1.02.tiff", -1); //input image
	namedWindow("Original Image");
	imshow("Original Image", image);

	int c;
	//Generating histogram for red
	c = 2;
	int histogram[256];
	histogramcalculation(image, histogram, c);

	// Caluculating the size of image
	int size = image.rows * image.cols;
	float factor = 255.0 / size;

	// Calculating PDF for red
	float PDF[256];
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)histogram[i] / size;
	}

	// Generating cumulative frequency for red
	int CFhistogram[256];
	CDFhistogram(histogram, CFhistogram);

	// Scaling histogram for red
	int ScaledIR[256];
	for (int i = 0; i < 256; i++)
	{
		ScaledIR[i] = cvRound((double)CFhistogram[i] * factor);
	}
	histogramDisplay(histogram, "Input Histogram Red");


	c = 1;
	histogramcalculation(image, histogram, c);

	// Calculating PDF for green
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)histogram[i] / size;
	}

	// Generating cumulative frequency for green
	CDFhistogram(histogram, CFhistogram);

	// Scaling histogram for green
	int ScaledIG[256];
	for (int i = 0; i < 256; i++)
	{
		ScaledIG[i] = cvRound((double)CFhistogram[i] * factor);
	}
	histogramDisplay(histogram, "Input Histogram Green");


	c = 0;
	histogramcalculation(image, histogram, c);

	// Calculating PDF for blue
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)histogram[i] / size;
	}

	// Generating cumulative frequency for blue
	CDFhistogram(histogram, CFhistogram);

	// Scaling histogram for blue
	int ScaledIB[256];
	for (int i = 0; i < 256; i++)
	{
		ScaledIB[i] = cvRound((double)CFhistogram[i] * factor);
	}
	histogramDisplay(histogram, "Input Histogram Blue");




	Mat image1 = imread("C:/Users/Vaibhav/Desktop/mandril_color.jpg", -1);//target image
	namedWindow("Target Image");
	imshow("Target Image", image1);

	//Generating histogram for target red
	c = 2;
	int histogram1[256];
	histogramcalculation(image1, histogram1, c);
	histogramDisplay(histogram1, "Target Histogram Red");

	// Calculating PDF for target red
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)histogram1[i] / size;
	}

	// Generating cumulative frequency for target red
	CDFhistogram(histogram1, CFhistogram);

	// Scaling histogram for target red
	int ScaledTR[256];
	for (int i = 0; i < 256; i++)
	{
		ScaledTR[i] = cvRound((double)CFhistogram[i] * factor);
	}



	c = 1;
	histogramcalculation(image1, histogram1, c);
	histogramDisplay(histogram1, "Target Histogram Green");

	// Calculating PDF for target green
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)histogram1[i] / size;
	}

	// Generating cumulative frequency for target green
	CDFhistogram(histogram1, CFhistogram);

	// Scaling histogram for target green
	int ScaledTG[256];
	for (int i = 0; i < 256; i++)
	{
		ScaledTG[i] = cvRound((double)CFhistogram[i] * factor);
	}


	c = 0;
	histogramcalculation(image1, histogram1, c);
	histogramDisplay(histogram1, "Target Histogram blue");

	// Calculating PDF for target blue
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)histogram1[i] / size;
	}

	// Generating cumulative frequency for target blue
	CDFhistogram(histogram1, CFhistogram);

	// Scaling histogram for target blue
	int ScaledTB[256];
	for (int i = 0; i < 256; i++)
	{
		ScaledTB[i] = cvRound((double)CFhistogram[i] * factor);
	}

	float x;
	int	k;
	int ScaledR[256];
	for (int i = 0; i < 256; i++)
	{
		k = 0;
		x = 256;
		for (int j = 0; j < 256; j++)
		{
			if (abs(ScaledIR[i] - ScaledTR[j]) < x)
			{
				x = abs(ScaledIR[i] - ScaledTR[j]);//finding mapping level for red
				k = j;
			}
		}
		ScaledR[i] = ScaledTR[k];//mapping input histogram red to target histogram red level
	}

	int finalR[256];
	for (int i = 1; i < 256; i++)
		finalR[i] = (ScaledR[i] - ScaledR[i - 1]);
	// Displaying mapped histogram for red
	histogramDisplay(finalR, "Mapped Histogram Red");



	int ScaledG[256];
	for (int i = 0; i < 256; i++)
	{
		k = 0;
		x = 256;
		for (int j = 0; j < 256; j++)
		{
			if (abs(ScaledIG[i] - ScaledTG[j]) < x)
			{
				x = abs(ScaledIG[i] - ScaledTG[j]);//finding mapping level for green
				k = j;
			}
		}
		ScaledG[i] = ScaledTG[k];//mapping input histogram green to target histogram green level
	}

	int finalG[256];
	for (int i = 1; i < 256; i++)
		finalG[i] = (ScaledG[i] - ScaledG[i - 1]);
	// Displaying mapped histogram for green
	histogramDisplay(finalG, "Mapped Histogram Green");




	int ScaledB[256];
	for (int i = 0; i < 256; i++)
	{
		k = 0;
		x = 256;
		for (int j = 0; j < 256; j++)
		{
			if (abs(ScaledIB[i] - ScaledTB[j]) < x)
			{
				x = abs(ScaledIB[i] - ScaledTB[j]);//finding mapping level for blue
				k = j;
			}
		}
		ScaledB[i] = ScaledTB[k];//mapping input histogram blue to target histogram blue level
	}

	int finalB[256];
	for (int i = 1; i < 256; i++)
		finalB[i] = (ScaledB[i] - ScaledB[i - 1]);
	// Displaying mapped histogram for blue
	histogramDisplay(finalB, "Mapped Histogram Blue");


	// Generating mapped image
	Mat new_image = image.clone();

	for (int y = 0; y < image.rows; y++)
		for (int x = 0; x < image.cols; x++)
		{
			new_image.at<Vec3b>(y, x)[2] = saturate_cast<uchar>(ScaledR[image.at<Vec3b>(y, x)[2]]);//obtaining new pixels from mapped histogram for red
			new_image.at<Vec3b>(y, x)[1] = saturate_cast<uchar>(ScaledG[image.at<Vec3b>(y, x)[1]]);//obtaining new pixels from mapped histogram for green
			new_image.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(ScaledB[image.at<Vec3b>(y, x)[0]]);//obtaining new pixels from mapped histogram for blue
		}

	// Display Mapped image
	namedWindow("Mapped Image");
	imshow("Mapped Image", new_image);
	imwrite("C:/Users/Vaibhav/Desktop/DIP/output exp2/mapped4.1.02.tiff",new_image);
	waitKey();
}


int main()
{
	HistMatchRGB();
	return 0;
}

