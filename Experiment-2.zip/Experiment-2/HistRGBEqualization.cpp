#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#define WIDTH 512
#define HEIGHT 512

using namespace std;
using namespace cv;


void histogramcalculation(Mat image, int histogram[], int c)
{

	// initializing all intensity levels to 0
	for (int i = 0; i < 256; i++)
	{
		histogram[i] = 0;
	}

	// calculating pixel density for each intensity level
	for (int y = 0; y < image.rows; y++)
		for (int x = 0; x < image.cols; x++)
			histogram[(int)image.at<Vec3b>(y, x)[c]]++;

}
       //calculating cumulative desnity for levels
void CDFhistogram(int histogram[], int CFhistogram[])
{
	CFhistogram[0] = histogram[0];

	for (int i = 1; i < 256; i++)
	{
		CFhistogram[i] = histogram[i] + CFhistogram[i - 1];
	}
}

     //creating and displaying histogram
void histogramDisplay(int histogram[], const char* name)
{
	int hist[256];
	for (int i = 0; i < 256; i++)
	{
		hist[i] = histogram[i];
	}
	// creating histograms
	int hist_w = 512; int hist_h = 400;
	int bin_w = cvRound((double)hist_w / 256);

	Mat histImage(hist_h, hist_w, CV_8UC1, Scalar(255, 255, 255));

	// finding maximum intensity element from histogram
	int max = hist[0];
	for (int i = 1; i < 256; i++) {
		if (max < hist[i]) {
			max = hist[i];
		}
	}

	// normalizing the histogram
	for (int i = 0; i < 256; i++) {
		hist[i] = ((double)hist[i] / max) * histImage.rows;
	}


	// draw the intensity line for histogram
	for (int i = 0; i < 256; i++)
	{
		line(histImage, Point(bin_w * (i), hist_h),
			Point(bin_w * (i), hist_h - hist[i]),
			Scalar(0, 0, 0), 1, 8, 0);
	}

	// displaying histogram
	namedWindow(name);
	imshow(name, histImage);
}



void HistRGB()
{
	Mat image = imread("C:/Users/Vaibhav/Desktop/lena_color_512.jpg", -1); //Input Image
	int c;
	// Caluculating the size of image
	int size = image.rows * image.cols;
	float factor = 255.0 / size;

	int HR[256]; //histogram for red
	int HG[256]; //histogram for green
	int HB[256];  //histogram for blue
	//Generate the histogram
	c = 2;
	histogramcalculation(image, HR,c);

	// Calculating PDF for red
	float PDF[256];
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)HR[i] / size;
	}

	// Generating cumulative frequency for red
	int CFhistogram[256];
	CDFhistogram(HR, CFhistogram);

	// Scaling the histogram
	int Scaledhist[256];
	for (int i = 0; i < 256; i++)
	{
		Scaledhist[i] = cvRound((double) CFhistogram[i] * factor);
	}

	// Generating equlized histogram for red
	float Eualizedhist[256];
	for (int i = 0; i < 256; i++)
	{
		Eualizedhist[i] = 0;
	}

	for (int i = 0; i < 256; i++)
	{
		Eualizedhist[Scaledhist[i]] += PDF[i];
	}

	int final[256];
	for (int i = 0; i < 256; i++)
		final[i] = cvRound(Eualizedhist[i] * 255);

	// Generating equlized image
	Mat new_image = image.clone();

	for (int y = 0; y < image.rows; y++)
		for (int x = 0; x < image.cols; x++)
			new_image.at<Vec3b>(y, x)[c] = saturate_cast<uchar>(Scaledhist[image.at<Vec3b>(y, x)[c]]);//for equlaized histogram of red

	// Display the original Histogram
	histogramDisplay(HR, "Original Histogram Red");

	// Display the equilzed histogram
	histogramDisplay(final, "Equilized Histogram Red");


	c = 1;
	histogramcalculation(image, HG, c);

	// Calculating PDF for green
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)HG[i] / size;
	}

	// Generating cumulative frequency histogram for green
	CDFhistogram(HG, CFhistogram);

	// Scaling histogram for green
	for (int i = 0; i < 256; i++)
	{
		Scaledhist[i] = cvRound((double)CFhistogram[i] * factor);
	}

	// Generating equilized histogram for green
	for (int i = 0; i < 256; i++)
	{
		Eualizedhist[i] = 0;
	}

	for (int i = 0; i < 256; i++)
	{
		Eualizedhist[Scaledhist[i]] += PDF[i];
	}

	for (int i = 0; i < 256; i++)
		final[i] = cvRound(Eualizedhist[i] * 255);


	for (int y = 0; y < image.rows; y++)
		for (int x = 0; x < image.cols; x++)
			new_image.at<Vec3b>(y, x)[c] = saturate_cast<uchar>(Scaledhist[image.at<Vec3b>(y, x)[c]]);//for equlaized histogram of green



	// Display the original Histogram
	histogramDisplay(HG, "Original Histogram Green");

	// Display the equilzed histogram
	histogramDisplay(final, "Equilized Histogram Green");


	c = 0;
	histogramcalculation(image, HB, c);

	// Calculating PDF for blue
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)HB[i] / size;
	}

	// Generating cumulative frequency for blue
	CDFhistogram(HB, CFhistogram);

	// Scaling histogram for blue
	for (int i = 0; i < 256; i++)
	{
		Scaledhist[i] = cvRound((double)CFhistogram[i] * factor);
	}


	// Generating equlized histogram for bue
	for (int i = 0; i < 256; i++)
	{
		Eualizedhist[i] = 0;
	}

	for (int i = 0; i < 256; i++)
	{
		Eualizedhist[Scaledhist[i]] += PDF[i];
	}

	for (int i = 0; i < 256; i++)
		final[i] = cvRound(Eualizedhist[i] * 255);

	for (int y = 0; y < image.rows; y++)
		for (int x = 0; x < image.cols; x++)
			new_image.at<Vec3b>(y, x)[c] = saturate_cast<uchar>(Scaledhist[image.at<Vec3b>(y, x)[c]]); //for equlaized histogram of blue


	// Display the original Histogram
	histogramDisplay(HB, "Original Histogram Blue");

	// Display the equilzed histogram
	histogramDisplay(final, "Equilized Histogram Blue");


	// Display the original Image
	namedWindow("Original Image");
	imshow("Original Image", image);

	// Display equilized image
	namedWindow("Equilized Image");
	imshow("Equilized Image", new_image);
	imwrite("C:/Users/Vaibhav/Desktop/DIP/output exp2/equilizedlena_color_512.jpg",new_image);

	waitKey();
}


int main()
{

   HistRGB();

	return 0;
}

