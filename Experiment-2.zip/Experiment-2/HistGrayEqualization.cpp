#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#define WIDTH 512
#define HEIGHT 512

using namespace std;
using namespace cv;

void histogramcalculation(Mat image, int histogram[])
{

	// initialize all intensity values to 0
	for (int i = 0; i < 256; i++)
	{
		histogram[i] = 0;
	}

	// calculate pixel density for each intensity level
	for (int y = 0; y < image.rows; y++)
		for (int x = 0; x < image.cols; x++)
			histogram[(int)image.at<uchar>(y, x)]++;

}

     //calculating cumulative density for each intensity level
void CDFhistogram(int histogram[], int CFhistogram[])
{
	CFhistogram[0] = histogram[0];

	for (int i = 1; i < 256; i++)
	{
		CFhistogram[i] = histogram[i] + CFhistogram[i - 1];
	}
}

void histogramDisplay(int histogram[], const char* name)
{
	int hist[256];
	for (int i = 0; i < 256; i++)
	{
		hist[i] = histogram[i];
	}
	// creating the histogram
	int hist_w = 512; int hist_h = 400;
	int bin_w = cvRound((double)hist_w / 256);

	Mat histImage(hist_h, hist_w, CV_8UC1, Scalar(255, 255, 255));

	// finding maximum intensity element from histogram
	int max = hist[0];
	for (int i = 1; i < 256; i++) {
		if (max < hist[i]) {
			max = hist[i];
		}
	}

	// normalizing the histogram 
	for (int i = 0; i < 256; i++) {
		hist[i] = ((double)hist[i] / max) * histImage.rows;
	}


	// draw the intensity line for histogram
	for (int i = 0; i < 256; i++)
	{
		line(histImage, Point(bin_w * (i), hist_h),
			Point(bin_w * (i), hist_h - hist[i]),
			Scalar(0, 0, 0), 1, 8, 0);
	}

	// displaying created histogram
	imshow(name, histImage);
}

void HistGRAY()
{ 
	Mat image = imread("C:/Users/Vaibhav/Desktop/DIP/DIP Experiment 2/Images for Histogram Equalization/Fig0309(a)(washed_out_aerial_image).tif", IMREAD_GRAYSCALE);
	//Generating the histogram
	int histogram[256];
	histogramcalculation(image, histogram);

	// Caluculate the size of input image
	int size = image.rows * image.cols;
	float factor = 255.0 / size;

	// Calculate the PDF
	float PDF[256];
	for (int i = 0; i < 256; i++)
	{
		PDF[i] = (double)histogram[i] / size;
	}

	// Generate cumulative frequency histogram
	int CFhistogram[256];
	CDFhistogram(histogram, CFhistogram);

	// Scale the histogram
	int Scaledhist[256];
	for (int i = 0; i < 256; i++)
	{
		Scaledhist[i] = cvRound((double)CFhistogram[i] * factor);
	}


	// Generating the equlized histogram
	float Equilzedhist[256];
	for (int i = 0; i < 256; i++)
	{
		Equilzedhist[i] = 0;
	}

	for (int i = 0; i < 256; i++)
	{
		Equilzedhist[Scaledhist[i]] += PDF[i];
	}

	int finalhist[256];
	for (int i = 0; i < 256; i++)
		finalhist[i] = cvRound(Equilzedhist[i] * 255);


	// Generate the equlized image
	Mat new_image = image.clone();

	for (int y = 0; y < image.rows; y++)
		for (int x = 0; x < image.cols; x++)
			new_image.at<uchar>(y, x) = saturate_cast<uchar>(Scaledhist[image.at<uchar>(y, x)]);

	// Display the original Image
	namedWindow("Original Image");
	imshow("Original Image", image);

	// Display the original Histogram
	histogramDisplay(histogram, "Original Histogram");

	// Display equilized image
	namedWindow("Equilized Image");
	imshow("Equilized Image", new_image);
	imwrite("C:/Users/Vaibhav/Desktop/DIP/output exp2/equalizedFig0309(a)(washed_out_aerial_image).tif",new_image);

	// Display the equilzed histogram
	histogramDisplay(finalhist, "Equilized Histogram");

	waitKey();
}


int main()
{
	HistGRAY();
	return 0;
}

