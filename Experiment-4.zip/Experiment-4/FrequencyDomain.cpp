#include <windows.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <iostream>
#include <cmath>
#include<complex>

# define M_PI 3.1416  /* pi */

using namespace cv;
using namespace std;
using std::complex;

// GLOBAL VARIABLES

// FILTER OPTIONS
const int IDEAL_LPF = 0;
const int IDEAL_HPF = 1;
const int GAUSSIAN_LPF = 2;
const int GAUSSIAN_HPF = 3;
const int BUTTER_LPF = 4;
const int BUTTER_HPF = 5;

// FILTER NAMES
const string filters[6] = { "IDEAL_LPF", "IDEAL_HPF", "GAUSSIAN_LPF", "GAUSSIAN_HPF", "BUTTER_LPF", "BUTTER_HPF" };

string files[7] = { "C:/Users/Vaibhav/Desktop/DIP/Experiment 3/Normal Images/jetplane.jpg", "C:/Users/Vaibhav/Desktop/DIP/Experiment 3/Normal Images/lake.jpg",
	   "C:/Users/Vaibhav/Desktop/DIP/Experiment 3/Normal Images/lena_gray_512.jpg","C:/Users/Vaibhav/Desktop/DIP/Experiment 3/Normal Images/livingroom.jpg",
	"C:/Users/Vaibhav/Desktop/DIP/Experiment 3/Normal Images/mandril_gray.jpg","C:/Users/Vaibhav/Desktop/DIP/Experiment 3/Normal Images/pirate.jpg",
	"C:/Users/Vaibhav/Desktop/DIP/Experiment 3/Normal Images/walkbridge.jpg" };



// GLOBAL PARAMETERS USED BY THE PARAMETERS
int cutoff_G = 1; // 0.1 to 1 @ inc = 0.1
int gaussianSigma_G = 1; // 1 to 100 @ inc = 10
int butterN_G = 1; // 1 to 10 @ inc = 1
int butterC_G = 1; // 0.1 to 1 @ inc = 0.1
int fileID = 0;
int filterID = 0;


// MAT DATA STRUCTURES FOR STORING THE IMAGES
Mat image;
Mat operated_img_FFT;
Mat Orig_img_FFT;
Mat FilterImg;
Mat IFFTImg;
float inc = 0.05;




template<typename T>
void Transpose(T** input_matrix, int N)
{
	T temp;
	for (int i = 0; i < N; i++) {
		T* start = input_matrix[i] + i;
		for (int j = i + 1; j < N; j++) {
			temp = input_matrix[i][j];
			input_matrix[i][j] = input_matrix[j][i];
			input_matrix[j][i] = temp;
		}
	}
}

template<typename T>
void FFTShift(T** input_matrix, int N)
{
	T temp;
	int offset = N / 2;
	for (int i = 0; i < offset; i++) {
		T* start = input_matrix[i] + i;
		for (int j = 0; j < offset; j++) {
			temp = input_matrix[i][j];
			input_matrix[i][j] = input_matrix[i + offset][j + offset];
			input_matrix[i + offset][j + offset] = temp;
		}
	}

	for (int i = N / 2; i < N; i++) {
		T* start = input_matrix[i] + i;
		for (int j = 0; j < offset; j++) {
			temp = input_matrix[i][j];
			input_matrix[i][j] = input_matrix[i - offset][j + offset];
			input_matrix[i - offset][j + offset] = temp;
		}
	}
}

template<typename T>
void FFTShift(Mat& input_matrix, int N)
{
	T temp;
	int offset = N / 2;
	for (int i = 0; i < offset; i++) {
		for (int j = 0; j < offset; j++) {
			temp = input_matrix.at<T>(i, j);
			input_matrix.at<T>(i, j) = input_matrix.at<T>(i + offset, j + offset);
			input_matrix.at<T>(i + offset, j + offset) = temp;
		}
	}

	for (int i = N / 2; i < N; i++) {
		for (int j = 0; j < offset; j++) {
			temp = input_matrix.at<T>(i, j);
			input_matrix.at<T>(i, j) = input_matrix.at<T>(i - offset, j + offset);
			input_matrix.at<T>(i - offset, j + offset) = temp;
		}
	}
}

complex<double>* FFT(uchar* x, int N, int arrSize, int zeroLoc, int gap)
{
	complex<double>* fft;
	fft = new complex<double>[N];

	int i;
	if (N == 2)
	{
		fft[0] = complex<double>(x[zeroLoc] + x[zeroLoc + gap], 0);
		fft[1] = complex<double>(x[zeroLoc] - x[zeroLoc + gap], 0);
	}
	else
	{
		complex<double> wN = complex<double>(cos(2 * M_PI / N), sin(-2 * M_PI / N));//exp(-j2*pi/N)
		complex<double> w = complex<double>(1, 0);
		gap *= 2;
		complex<double>* X_even = FFT(x, N / 2, arrSize, zeroLoc, gap); //N/2 POINT DFT OF EVEN X's
		complex<double>* X_odd = FFT(x, N / 2, arrSize, zeroLoc + (arrSize / N), gap); //N/2 POINT DFT OF ODD X's
		complex<double> todd;
		for (i = 0; i < N / 2; ++i)
		{
			todd = w * X_odd[i];
			fft[i] = X_even[i] + todd;
			fft[i + N / 2] = X_even[i] - todd;
			w = w * wN;
		}

		delete[] X_even;
		delete[] X_odd;
	}

	return fft;
}

complex<double>* FFT(complex<double>* x, int N, int arrSize, int zeroLoc, int gap)
{
	complex<double>* fft;
	fft = new complex<double>[N];

	int i;
	if (N == 2)
	{
		fft[0] = x[zeroLoc] + x[zeroLoc + gap];
		fft[1] = x[zeroLoc] - x[zeroLoc + gap];
	}
	else
	{
		complex<double> wN = complex<double>(cos(2 * M_PI / N), sin(-2 * M_PI / N));//exp(-j2*pi/N)
		complex<double> w = complex<double>(1, 0);
		gap *= 2;
		complex<double>* X_even = FFT(x, N / 2, arrSize, zeroLoc, gap); //N/2 POINT DFT OF EVEN X's
		complex<double>* X_odd = FFT(x, N / 2, arrSize, zeroLoc + (arrSize / N), gap); //N/2 POINT DFT OF ODD X's
		complex<double> todd;
		for (i = 0; i < N / 2; ++i)
		{
			todd = w * X_odd[i];
			fft[i] = X_even[i] + todd;
			fft[i + N / 2] = X_even[i] - todd;
			w = w * wN;
		}

		delete[] X_even;
		delete[] X_odd;
	}

	return fft;
}

complex<double>* IFFT(complex<double>* fft, int N, int arrSize, int zeroLoc, int gap)
{
	complex<double>* signal;
	signal = new complex<double>[N];

	int i;
	if (N == 2)
	{
		signal[0] = fft[zeroLoc] + fft[zeroLoc + gap];
		signal[1] = fft[zeroLoc] - fft[zeroLoc + gap];
	}
	else
	{
		complex<double> wN = complex<double>(cos(2 * M_PI / N), sin(2 * M_PI / N));//exp(j2*pi/N)
		complex<double> w = complex<double>(1, 0);
		gap *= 2;
		complex<double>* X_even = IFFT(fft, N / 2, arrSize, zeroLoc, gap); //N/2 POINT DFT OF EVEN X's
		complex<double>* X_odd = IFFT(fft, N / 2, arrSize, zeroLoc + (arrSize / N), gap); //N/2 POINT DFT OF ODD X's
		complex<double> todd;
		for (i = 0; i < N / 2; ++i)
		{
			todd = w * X_odd[i];
			signal[i] = (X_even[i] + todd) * 0.5;
			signal[i + N / 2] = (X_even[i] - todd) * 0.5;
			w = w * wN; // Get the next root(conjugate) among Nth roots of unity
		}

		delete[] X_even;
		delete[] X_odd;
	}

	return signal;
}

complex<double>** FFT2(Mat& orig_image) {
	cout << "Applying FFT2" << endl;

	if (orig_image.rows != orig_image.cols) {
		cout << "Image is not Valid";
		return nullptr;
	}
	int N = orig_image.rows;
	//cout << "Image size:" << N << endl;
	complex<double>** FFT2Result_h;
	FFT2Result_h = new complex<double> *[N];

	// ROW WISE FFT
	for (int i = 0; i < N; i++) {
		uchar* row = orig_image.ptr<uchar>(i);
		FFT2Result_h[i] = FFT(row, N, N, 0, 1);
	}

	//cout << "final: " << endl;
	Transpose<complex<double>>(FFT2Result_h, N);

	// COLUMN WISE FFT
	for (int i = 0; i < N; i++) {
		FFT2Result_h[i] = FFT(FFT2Result_h[i], N, N, 0, 1);
	}
	Transpose<complex<double>>(FFT2Result_h, N);

	return FFT2Result_h;
}

complex<double>** IFFT2(complex<double>** orig_image, int N) {

	cout << "Applying IFFT2" << endl;

	complex<double>** ifftResult;
	ifftResult = new complex<double> *[N];
	// ROW WISE FFT
	for (int i = 0; i < N; i++) {
		ifftResult[i] = IFFT(orig_image[i], N, N, 0, 1);
	}

	//cout << "final: " << endl;
	Transpose<complex<double>>(ifftResult, N);

	complex<double> d = N * N;
	// COLUMN WISE FFT
	for (int i = 0; i < N; i++) {
		ifftResult[i] = IFFT(ifftResult[i], N, N, 0, 1);
		for (int j = 0; j < N; j++) {
			ifftResult[i][j] = ifftResult[i][j] / d;
		}
	}
	Transpose<complex<double>>(ifftResult, N);

	cout << endl;

	return ifftResult;
}

void comp_to_mat(complex<double>** orig_image, Mat& dest, int N, bool shift = false, float maxF = 1.0) {
	if (shift) {
		FFTShift(orig_image, N);
	}
	dest = Mat(N, N, CV_32F, cv::Scalar::all(0));
	float min = 99999;
	float max = 0;
	complex<double> n = N;
	// Find min and max
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			orig_image[i][j] = orig_image[i][j] / n;
			float m = abs(orig_image[i][j]);
			if (m < min) {
				min = m;
			}
			if (m > max) {
				max = m;
			}
		}
	}

	// Normalize the image
	float range = (max - min);
	for (int i = 0; i < N; i++) {
		float* p = dest.ptr<float>(i);
		for (int j = 0; j < N; j++) {
			p[j] = (abs(orig_image[i][j]) - min) * maxF / range;
		}
	}
}

void ApplyFilter(complex<double>** orig_image, Mat& filterImg, int N, int FilterType) {
	float cutoff = cutoff_G * inc; //Compute Ideal filter cutoff
	float sigma_squared = gaussianSigma_G * inc + inc; //Compute Gaussing filter sigma from trackbar input
	int butter_n = butterN_G; // Butterworth parameter n
	cutoff *= cutoff; // Square it to avoid further sqrt
	filterImg = Mat(N, N, CV_32F); // Image for showing the frequency spectrum of the filter
	float d = N * N;
	complex<double>** filterFFT;
	switch (FilterType) {
	case IDEAL_LPF:
		for (int i = 0; i < N / 2; i++) {
			for (int j = 0; j < N / 2; j++) {
				float f = (i * i / d) + (j * j / d);
				if (i == 5 && j == 5) {
					cout << "Cutoff Frequency is:" << f << endl;
				}
				if (f > cutoff) {
					// Remove the components outside the
					// cutoff frequency
					orig_image[i][j] = 0;
					orig_image[N - 1 - i][N - 1 - j] = 0;
					orig_image[N - 1 - i][j] = 0;
					orig_image[i][N - 1 - j] = 0;
				}
				else {
					// Filter coeff = 1 withing cutoff frequency range
					filterImg.at<float>(i, j) = filterImg.at<float>(N - 1 - i, N - 1 - j) = filterImg.at<float>(N - 1 - i, j) = filterImg.at<float>(i, N - 1 - j) = 1;
				}
			}
		}
		break;
	case IDEAL_HPF:
		for (int i = 0; i < N / 2; i++) {
			for (int j = 0; j < N / 2; j++) {
				float f = (i * i / d) + (j * j / d);
				if (i == 5 && j == 5) {
					cout << "Cutoff Frequency is:" << f << endl;
				}
				if (f <= cutoff) {
					// Remove the components @ less than the
					// cutoff frequency
					orig_image[i][j] = 0;
					orig_image[N - 1 - i][N - 1 - j] = 0;
					orig_image[N - 1 - i][j] = 0;
					orig_image[i][N - 1 - j] = 0;
				}
				else {
					// Filter coeff = 1 withing cutoff frequency range
					filterImg.at<float>(i, j) = filterImg.at<float>(N - 1 - i, N - 1 - j) = filterImg.at<float>(N - 1 - i, j) = filterImg.at<float>(i, N - 1 - j) = 1;
				}
			}
		}
		break;
	case GAUSSIAN_LPF:
		for (int i = 0; i < N / 2; i++) {
			for (int j = 0; j < N / 2; j++) {
				float wx2 = pow(2 * M_PI * i / N, 2); // omega x squared
				float wy2 = pow(2 * M_PI * j / N, 2); // omega y squared
				float coeff = exp(-(wx2 + wy2) / (2 * 1)); // Gaussian filter coeff @ (wx, wy)
				orig_image[i][j] *= coeff;
				orig_image[N - 1 - i][N - 1 - j] *= coeff;
				orig_image[N - 1 - i][j] *= coeff;
				orig_image[i][N - 1 - j] *= coeff;

				filterImg.at<float>(i, j) = filterImg.at<float>(N - 1 - i, N - 1 - j) = filterImg.at<float>(N - 1 - i, j) = filterImg.at<float>(i, N - 1 - j) = coeff;
			}
		}
		break;
	case GAUSSIAN_HPF:
		for (int i = 0; i < N / 2; i++) {
			for (int j = 0; j < N / 2; j++) {
				float wx2 = pow(2 * M_PI * i / N, 2); // omega x squared
				float wy2 = pow(2 * M_PI * j / N, 2); // omega y squared
				float coeff = 1 - exp(-(wx2 + wy2) / (2 * sigma_squared)); // Gaussian filter coeff @ (wx, wy)
				orig_image[i][j] *= coeff;
				orig_image[N - 1 - i][N - 1 - j] *= coeff;
				orig_image[N - 1 - i][j] *= coeff;
				orig_image[i][N - 1 - j] *= coeff;

				filterImg.at<float>(i, j) = filterImg.at<float>(N - 1 - i, N - 1 - j) = filterImg.at<float>(N - 1 - i, j) = filterImg.at<float>(i, N - 1 - j) = coeff;

			}
		}
		break;
	case BUTTER_LPF:
		cutoff = pow((butterC_G * inc + inc) * M_PI, 2);
		for (int i = 0; i < N / 2; i++) {
			for (int j = 0; j < N / 2; j++) {
				float wx2 = pow(2 * M_PI * i / N, 2);
				float wy2 = pow(2 * M_PI * j / N, 2);
				float coeff = 1 / (1 + pow((wx2 + wy2) / cutoff, 2 * butter_n)); // Butterworth filter coeff @ (wx, wy)
				orig_image[i][j] *= coeff;
				orig_image[N - 1 - i][N - 1 - j] *= coeff;
				orig_image[N - 1 - i][j] *= coeff;
				orig_image[i][N - 1 - j] *= coeff;

				filterImg.at<float>(i, j) = filterImg.at<float>(N - 1 - i, N - 1 - j) = filterImg.at<float>(N - 1 - i, j) = filterImg.at<float>(i, N - 1 - j) = coeff;

			}
		}
		break;
	case BUTTER_HPF:
		cutoff = pow((butterC_G * inc + inc) * M_PI, 2);
		for (int i = 0; i < N / 2; i++) {
			for (int j = 0; j < N / 2; j++) {
				float wx2 = pow(2 * M_PI * i / N, 2);
				float wy2 = pow(2 * M_PI * j / N, 2);
				float coeff = 1 / (1 + pow(cutoff / (wx2 + wy2), 2 * butter_n)); // Butterworth filter coeff @ (wx, wy)
				orig_image[i][j] *= coeff;
				orig_image[N - 1 - i][N - 1 - j] *= coeff;
				orig_image[N - 1 - i][j] *= coeff;
				orig_image[i][N - 1 - j] *= coeff;

				filterImg.at<float>(i, j) = filterImg.at<float>(N - 1 - i, N - 1 - j) = filterImg.at<float>(N - 1 - i, j) = filterImg.at<float>(i, N - 1 - j) = coeff;

			}
		}
		break;
	}
}

// Event handlers for trackbars
void apply_filter(string filename) {

	if (!image.data)
	{
		cout << "Could not open or find the image" << std::endl;
		return;
	}
	switch (filterID) {
	case IDEAL_LPF:
		cout << "Applying IDEAL_LPF" << endl;
		break;
	case IDEAL_HPF:
		cout << "Applying IDEAL_HPF" << endl;
		break;
	case GAUSSIAN_LPF:
		cout << "Applying GAUSSIAN_LPF" << endl;
		break;
	case GAUSSIAN_HPF:
		cout << "Applying GAUSSIAN_HPF" << endl;
		break;
	case BUTTER_LPF:
		cout << "Applying BUTTER_LPF" << endl;
		break;
	case BUTTER_HPF:
		cout << "Applying BUTTER_HPF" << endl;
		break;
	}
	complex<double>** fft2result = FFT2(image);
	comp_to_mat(fft2result, Orig_img_FFT, image.rows, false, 255);
	// Apply Filter
	ApplyFilter(fft2result, FilterImg, image.rows, filterID);
	// Roate the FFT input_matrix to bring freq(0, 0) at the middle of the image
	FFTShift<float>(FilterImg, image.rows);

	complex<double>** ifft2result = IFFT2(fft2result, image.rows);
	float maxF = 1;
	switch (filterID) {
	case IDEAL_LPF:
	case GAUSSIAN_LPF:
	case BUTTER_LPF:
		maxF = 255;
	}
	comp_to_mat(fft2result, operated_img_FFT, image.rows, true, maxF);
	comp_to_mat(ifft2result, IFFTImg, image.rows);


	FFTShift<float>(Orig_img_FFT, image.rows);

	// Show the results
	imshow("Original FFT", Orig_img_FFT);
	imshow("Filtered FFT", operated_img_FFT);
	imshow("Filter Spectrum", FilterImg);
	imshow("Output Image", IFFTImg);
}

void on_cutoff_change(int, void*) {
	apply_filter(files[fileID]);
}


void on_butterN_change(int, void*) {
	apply_filter(files[fileID]);
}

void on_butterC_change(int, void*) {
	apply_filter(files[fileID]);
}
void on_file_change(int, void*) {

	image = imread(files[fileID], IMREAD_GRAYSCALE); // Read the file

	if (!image.data) // Check for invalid input
	{
		cout << "Could not open or find the image" << endl;
		return;
	}
	imshow("Input Image", image); // Show our image inside it.
	apply_filter(files[fileID]);
}

void on_filter_hange(int, void*) {
	apply_filter(files[fileID]);
}

int main()
{
	int displaySize = 400;

	cv::namedWindow("Options", 0);
	// Create trackbars
	createTrackbar("Image", "Options", &fileID, 7, on_file_change);
	createTrackbar("Filter", "Options", &filterID, 5, on_filter_hange);
	createTrackbar("Ideal Filter cutoff ", "Options", &cutoff_G, 0.5 / inc, on_cutoff_change); // cutoff
	createTrackbar("ButterWorth n ", "Options", &butterN_G, 10, on_butterN_change); // butterworth n
	createTrackbar("ButterWorth c", "Options", &butterC_G, 1 / inc, on_butterC_change); // butterworth c

	// Create the windows for showing results
	cv::namedWindow("Filter Spectrum", 0);
	resizeWindow("Filter Spectrum", displaySize, displaySize);

	cv::namedWindow("Output Image", 0);
	resizeWindow("Output Image", displaySize, displaySize);

	on_file_change(0, 0);
	on_filter_hange(0, 0);
	on_cutoff_change(0, 0);
	waitKey(0);
	return 0;
}