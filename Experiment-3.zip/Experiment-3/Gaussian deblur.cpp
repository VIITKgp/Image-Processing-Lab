
#include<opencv2/opencv.hpp>
#include<iostream>
#include<conio.h>
#include<stdint.h>
#include<math.h>
using namespace std;
using namespace cv;

Mat makeGauss(Mat img);
void makeZero(uint8_t** arr, int d);
void makezero(float** arr, int d);
void getMatrix(Mat img, uint8_t** mat3, int R, int C, int d);
float getGauss(uint8_t** mat3, float** kernel, int d, int f);
float Matmult(uint8_t** mat3, float** kernel, int d, int f);
Mat makeDeblur(Mat img, int d);
Mat convolve(Mat img, float** kh, int d, float** Mtx, float** result);
Mat Mul(Mat img, Mat img2, float** Mtx, float** result);
Mat Div(Mat img, Mat img2, float** Mtx, float** result);
float getgauss(float** Mtx, float** kernel, int d, int f);
float matmult(float** mat3, float** kernel, int d, int f);
void getmatrix(Mat img, float** Mtx, float** target, int R, int C, int d);



void makeZero(uint8_t** arr, int d)
{
	for (int i = 0; i < d; i++)
		for (int j = 0; j < d; j++)
			*(*(arr + i) + j) = 0;
}

void makezero(float** arr, int d)
{
	{
		for (int i = 0; i < d; i++)
			for (int j = 0; j < d; j++)
				*(*(arr + i) + j) = 0.0;
	}

}

float getGauss(uint8_t** mat3, float** kernel, int d, int f = 0)
{
	float res = 0;
	res = Matmult(mat3, kernel, d, f);
	return res;
}

float getgauss(float** Mtx, float** kernel, int d, int f = 0)
{
	float res = 0;
	res = matmult(Mtx, kernel, d, f);
	return res;
}

float Matmult(uint8_t** mat3, float** kernel, int d, int f = 0)
{
	float res = 0;
	for (int i = 0; i < d; i++) {
		for (int j = 0; j < d; j++) {
			res = res + (kernel[i][j] * (float)mat3[i][j]);
			if (f == 1)
			{
				cout << "\nFor combination " << i + 1 << "*" << j + 1 << "  Values of kernel:" << (int)kernel[i][j] << "  Values of matrix point:" << (int)mat3[i][j];
			}
		}
	}
	if (f == 1)
		cout << "\nReturn Value:" << (int)abs(res);
	return abs(res);
}

float matmult(float** mat3, float** kernel, int d, int f = 0)
{
	float res = 0;
	for (int i = 0; i < d; i++) {
		for (int j = 0; j < d; j++) {
			res = res + (kernel[i][j] * (float)mat3[i][j]);
			if (f == 1)
			{
				cout << "\nFor combination " << i + 1 << "*" << j + 1 << "  Values of kernel:" << (int)kernel[i][j] << "  Values of matrix point:" << (int)mat3[i][j];
			}
		}
	}
	if (f == 1)
		cout << "\nReturn Value:" << (int)abs(res);
	return abs(res);
}

void getMatrix(Mat img, uint8_t** mat3, int R, int C, int d)
{

	int x = d - 1;
	x = x / 2;
	int r = R - x;
	int c = C - x;
	for (int i = 0; i < d; i++) {
		for (int j = 0; j < d; j++) {
			if ((r + i) >= 0 && (c + j) >= 0 && (r + i) < img.rows && (c + j) < img.cols) {
				mat3[i][j] = img.at<uint8_t>(r + i, c + j);
			}
			else
				mat3[i][j] = 0;
		}
	}
}

void getmatrix(Mat img, float** Mtx, float** target, int R, int C, int d)
{

	int x = d - 1;
	x = x / 2;
	int r = R - x;
	int c = C - x;
	for (int i = 0; i < d; i++) {
		for (int j = 0; j < d; j++) {
			if ((r + i) >= 0 && (c + j) >= 0 && (r + i) < img.rows && (c + j) < img.cols) {
				target[i][j] = Mtx[r + i][c + j];
			}
			else
				target[i][j] = 0;
		}
	}
}

Mat makeGauss(Mat img)
{

	int d = 7;
	uint8_t** mat3 = new uint8_t * [d];
	for (int i = 0; i < d; i++)
		mat3[i] = new uint8_t[d];

	float** kh = new float* [d];
	for (int i = 0; i < d; i++)
		kh[i] = new float[d];

	float den = 0;

	for (int i = 0; i < d; i++)
		for (int j = 0; j < d; j++) {
			kh[i][j] = exp(-(pow(i - (d - 1) / 2, 2) + pow(j - (d - 1) / 2, 2)) / 2.0);
			den += kh[i][j];
		}

	for (int i = 0; i < d; i++) {
		for (int j = 0; j < d; j++) {
			kh[i][j] /= den;
		}
	}


	int a = img.rows / 2, b = img.cols / 2;
	Mat img2 = img.clone();
	int dx = 0, dy = 0, diff = 0;
	for (int r = 0; r < img.rows; r++) {
		for (int c = 0; c < img.cols; c++) {
			makeZero(mat3, d);
			getMatrix(img, mat3, r, c, d);
			if (r == a && c == b) {
				int y = getGauss(mat3, kh, d, 1);

			}
			dx = getGauss(mat3, kh, d);
			img2.at<uint8_t>(r, c) = (uint8_t)dx;
			
		}
	}

	return img2;
}



Mat makeDeblur(Mat img, int d)
{

	float** kh = new float* [d];
	for (int i = 0; i < d; i++)
		kh[i] = new float[d];

	float** Mtx = new float* [img.rows];
	for (int i = 0; i < img.rows; i++)
		Mtx[i] = new float[img.cols];

	float den = 0;
	float sig = 5.5;
	for (int i = 0; i < d; i++)
		for (int j = 0; j < d; j++) {
			kh[i][j] = exp(-(pow(i - (d - 1) / 2, 2) + pow(j - (d - 1) / 2, 2)) / (2.0 * sig * sig));
			den += kh[i][j];
		}

	for (int i = 0; i < d; i++)
		for (int j = 0; j < d; j++) {
			kh[i][j] /= den;
		}

	for (int i = 0; i < img.rows; i++)
		for (int j = 0; j < img.cols; j++) {
			Mtx[i][j] = img.at<uint8_t>(i, j);
		}

	float** result = new float* [img.rows];
	for (int i = 0; i < img.rows; i++)
		result[i] = new float[img.cols];


	Mat dblr = img.clone();
	Mat dblr2 = img.clone();
	Mat Ak = img.clone();
	Mat Bk = img.clone();
	Mat Ck = img.clone();
	for (int k = 0; k < 10; k++)
	{
		Ak = convolve(dblr, kh, d, Mtx, result);
		Bk = Div(img, Ak, Mtx, result);
		Ck = convolve(Bk, kh, d, Mtx, result);
		for (int i = 0; i < img.rows; i++)
			for (int j = 0; j < img.cols; j++) {
				Mtx[i][j] = img.at<uint8_t>(i, j);
			}
		dblr = Mul(img, Ck, Mtx, result);
		for (int i = 0; i < img.rows; i++)
			for (int j = 0; j < img.cols; j++) {
				dblr.at<uint8_t>(i, j) = (uint8_t)result[i][j];
			}
	}

	return dblr;

}

Mat Mul(Mat img, Mat img2, float** Mtx, float** result) {
	Mat Res = img.clone();
	uint8_t a, b;
	for (int i = 0; i < img.rows; i++) {
		for (int j = 0; j < img.cols; j++) {
			a = img.at<uint8_t>(i, j);
			b = img2.at<uint8_t>(i, j);
			result[i][j] = Mtx[i][j] * result[i][j];
			if (a * b < 255)
			{
				Res.at<uint8_t>(i, j) = a * b;
			}
		}
	}
	return Res;
}

Mat Div(Mat img, Mat img2, float** Mtx, float** result) {
	Mat Res = img.clone();
	uint8_t a, b;
	for (int i = 0; i < img.rows; i++) {
		for (int j = 0; j < img.cols; j++) {
			a = img.at<uint8_t>(i, j);
			b = img2.at<uint8_t>(i, j);
			if (b >= 1) {
				Res.at<uint8_t>(i, j) = a / b;
				Mtx[i][j] = Mtx[i][j] / result[i][j];
			}
		}
	}
	return Res;
}

Mat convolve(Mat img, float** kh, int d, float** Mtx, float** result) {

	Mat img2 = img.clone();

	uint8_t** mat3 = new uint8_t * [d];
	for (int i = 0; i < d; i++)
		mat3[i] = new uint8_t[d];


	float** target = new float* [d];
	for (int i = 0; i < d; i++)
		target[i] = new float[d];


	int dx = 0;
	float Dx = 0;
	for (int r = 0; r < img.rows; r++) {
		for (int c = 0; c < img.cols; c++) {
			makeZero(mat3, d);
			makezero(target, d);
			getMatrix(img, mat3, r, c, d);
			getmatrix(img, Mtx, target, r, c, d);
			dx = getGauss(mat3, kh, d);
			Dx = getgauss(target, kh, d);
			img2.at<uint8_t>(r, c) = (uint8_t)dx;
			result[r][c] = Dx;

		}
	}

	return img2;


}



int main()
{
	Mat img = imread("C:/Users/Vaibhav/Desktop/DIP/Experiment 3/Normal Images/livingroom.jpg", IMREAD_GRAYSCALE);
	Mat img2 = img.clone();
	int d = 3;
	img2 = makeGauss(img);
	Mat deb = makeDeblur(img2, d);

	imshow("Blurred Image", img2);
	imshow("Deblurred Image", deb);

	imwrite("Blurred.jpg", img2);
	imwrite("Deblurred.jpg", deb);

	waitKey();
	return 0;
}



