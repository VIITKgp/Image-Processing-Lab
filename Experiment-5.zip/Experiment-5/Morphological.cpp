#include <iostream>
#include <algorithm>
#include <vector>
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/core.hpp"


using namespace std;
using namespace cv;

int type = 0;
int K = 0;
int kernelSize = 3;

Mat OneDErosion(Mat img)
{
	Mat img2 = img.clone();
	for (int i = 0; i < img.rows - 1; i++) {
		for (int j = 0; j < img.cols - 1; j++) {
			int v1, v2;
			v1 = img.at<uchar>(i, j);
			v2 = img.at<uchar>(i, j + 1);
			int a = min(v1, v2);
			img2.at<uchar>(i, j) = a;
			img2.at<uchar>(i, j + 1) = a;

		}
	}
	//imshow("After Erosion", img2);
	return  img2;
}

Mat OneDDilation(Mat img)
{
	Mat img2 = img.clone();
	for (int i = 0; i < img.rows - 1; i++) {
		for (int j = 0; j < img.cols - 1; j++) {
			int v1, v2;
			v1 = img.at<uchar>(i, j);
			v2 = img.at<uchar>(i, j + 1);
			int a = max(v1, v2);
			img2.at<uchar>(i, j) = a;
			img2.at<uchar>(i, j + 1) = a;

		}
	}
	//imshow("After Dilation", img2);
	return img2;
}
void OneDkernel(Mat img)
{   
	imshow("Input Image", img);
	Mat img2 = img.clone();
	img2 = OneDErosion(img);
	imshow("]Image after Erosion", img2);
	img2 = OneDDilation(img);
	imshow("Image after Dilation", img2);
	img2 = OneDErosion(img);
	img2 = OneDDilation(img2);
	imshow("Image after Opening", img2);
	img2 = OneDDilation(img);
	img2 = OneDErosion(img2);
	imshow("Image after Closing", img2);
	waitKey(0);
}

Mat DiamondErosion(Mat img)
{
	Mat img2 = img.clone();
	for (int i = 1; i < img.rows - 1; i++) {
		for (int j = 1; j < img.cols - 1; j++) {
			std::vector<int> v;
			v.push_back(img.at<uchar>(i, j));
			v.push_back(img.at<uchar>(i, j + 1));
			v.push_back(img.at<uchar>(i+1, j));
			v.push_back(img.at<uchar>(i-1, j ));
			v.push_back(img.at<uchar>(i, j - 1));
			int a = *min_element(v.begin(), v.end());
			for (int k = i - 1; k < i + 1; k++) {
				for (int l = j - 1; l < j + 1; l++) {
					img2.at<uchar>(k, l) = a;
				}
			}
		}
	}
	//imshow("After Erosion", img2);
	return  img2;
}

Mat DiamondDilation(Mat img)
{
	Mat img2 = img.clone();
	for (int i = 1; i < img.rows - 1; i++) {
		for (int j = 1; j < img.cols - 1; j++) {
			std::vector<int> v;
			v.push_back(img.at<uchar>(i, j));
			v.push_back(img.at<uchar>(i, j + 1));
			v.push_back(img.at<uchar>(i + 1, j));
			v.push_back(img.at<uchar>(i - 1, j));
			v.push_back(img.at<uchar>(i, j - 1));
			int a = *max_element(v.begin(), v.end());
			for (int k = i-1; k < i + 1; k++) {
				for (int l = j-1; l < j + 1; l++) {
					img2.at<uchar>(k, l) = a;
				}
			}

		}
	}
	//imshow("After Dilation", img2);
	return img2;
}
void Diamondkernel(Mat img)
{
	imshow("Input Image", img);
	Mat img2 = img.clone();
	img2 = DiamondErosion(img);
	imshow("]Image after Erosion", img2);
	img2 = DiamondDilation(img);
	imshow("Image after Dilation", img2);
	img2 = DiamondErosion(img);
	img2 = DiamondDilation(img2);
	imshow("Image after Opening", img2);
	img2 = DiamondDilation(img);
	img2 = DiamondErosion(img2);
	imshow("Image after Closing", img2);
	waitKey(0);
}



Mat erosion(Mat img,int size)
{
	Mat img2 = img.clone();
	for (int i = 0; i < img.rows - size+1; i++) {
		for (int j = 0; j < img.cols - size + 1; j++) {
			std::vector<int> v;
			for (int k = i; k < i + size; k++) {
				for (int l = j; l < j + size; l++) {
					v.push_back(img.at<uchar>(k, l));
				}
			}
			int a = *min_element(v.begin(), v.end());
			for (int k = i; k < i + size; k++) {
				for (int l = j; l < j + size; l++) {
					img2.at<uchar>(k, l) = a;
				}
			}
		}
	}
	return img2;
	//imshow("Erosion", img2);
}

Mat dilation(Mat img,int size)
{
	Mat img2 = img.clone();
	for (int i = 0; i < img.rows - size + 1; i++) {
		for (int j = 0; j < img.cols - size + 1; j++) {
			std::vector<int> v;
			for (int k = i; k < i + size; k++) {
				for (int l = j; l < j + size; l++) {
					v.push_back(img.at<uchar>(k, l));
				}
			}
			int a = *max_element(v.begin(), v.end());
			for (int k = i; k < i + size; k++) {
				for (int l = j; l < j + size; l++) {
					img2.at<uchar>(k, l) = a;
				}
			}
		}
	}
	return img2;
	//imshow("Dilation", img2);
}

Mat Opening(Mat input, int size)
{
	Mat output = input.clone();
	output = erosion(input,size);
	output = dilation(output,size);
	//imshow("filtered after opening", output);
	return output;
}

Mat Closing(Mat input,int size)
{
	Mat output = input.clone();
	output = dilation(input,size);
	output = erosion(output,size);
	//imshow("filtered after closing", output);
	return output;
}


void ontypeChange(int x, void*) {

	Mat img = imread("C:/Users/Vaibhav/Desktop/ricegrains_mono.bmp", IMREAD_GRAYSCALE);
	Mat img2 = img.clone();
	switch (type) {
	case 0:
		img2 = erosion(img, kernelSize);
		break;
	case 1:
		img2 = dilation(img, kernelSize);
		break;
	case 2:
		img2 = Opening(img, kernelSize);
		break;
	case 3:
		img2 = Closing(img, kernelSize);
		break;
	}
	imshow("Output Image", img2);
}

void onsizeChange(int x, void*)
{
	switch (K) {
	case 0:
		kernelSize = 3;
		break;
	case 1:
		kernelSize = 9;
		break;
	case 2:
		kernelSize = 15;
		break;
	}
	ontypeChange(type, 0);
}

void TwoDkernel(Mat img)
{
	cv::namedWindow("Input Image", cv::WINDOW_AUTOSIZE);
	cv::namedWindow("Output Image", cv::WINDOW_AUTOSIZE);
	createTrackbar("Method", "Output Image", &type, 3, ontypeChange);
	createTrackbar("Kernel size", "Output Image", &K, 2, onsizeChange);
	ontypeChange(0, 0);
	onsizeChange(0, 0);
	waitKey(0);
}

int main()
{
	Mat img = imread("C:/Users/Vaibhav/Desktop/ricegrains_mono.bmp", IMREAD_GRAYSCALE);
	imshow("Input Image", img);
	
	//TwoDkernel(img);
	//OneDkernel(img);
        //Diamondkernel(img);
}