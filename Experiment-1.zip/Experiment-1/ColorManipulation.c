#include<stdio.h>
#include<stdlib.h>
#define HEADER_SIZE 14
#define INFO_HEADER_SIZE 40
#define BITMAP_SIZE 1024

typedef unsigned int int32;
typedef unsigned char byte;

void Manipulation()
{
    byte BITMAP_header[HEADER_SIZE];//reading BMP header
    byte DIB_header[INFO_HEADER_SIZE];//reading Info header
	FILE *fptr1, *fptr2;
    char c;
    fptr1 = fopen("corn.bmp", "rb");
    fread(&BITMAP_header,HEADER_SIZE,1,fptr1);
    fread(&DIB_header,INFO_HEADER_SIZE,1,fptr1);


    fptr1 = fopen("corn.bmp", "rb");
    fptr2 = fopen("CornNoGREEN.bmp", "wb");
    fseek(fptr1,0,SEEK_SET);
    c = fgetc(fptr1);//reading value from input file
    int i=0;
    int start=HEADER_SIZE+INFO_HEADER_SIZE;
    int finish=HEADER_SIZE+INFO_HEADER_SIZE+BITMAP_SIZE;
    while (c != EOF)
    {
        fputc(c, fptr2);//placing value in output file
        i++;
        c = fgetc(fptr1);//reading value from input file
        if((i>=start)&&(i<=finish))
        {
        	if(((i-54)%4==1))
        	{
        		c=0;//setting green color channel to zero
			}
		}
    }

    fptr2 = fopen("CornNoRED.bmp", "wb");
	fseek(fptr1,0,SEEK_SET);
    c = fgetc(fptr1);//reading value from input file
    i=0;
    while (c != EOF)
    {
        fputc(c, fptr2);//placing value in output file
        i++;
        c = fgetc(fptr1);//reading value from input file
        if((i>=start)&&(i<=finish))
        {
        	if(((i-54)%4==2))
        	{
        		c=0;//setting red color channel to zero
			}
		}
    }

	fptr2 = fopen("CornNoBLUE.bmp", "wb");
	fseek(fptr1,0,SEEK_SET);
	c=fgetc(fptr1);//reading value from input file
    i=0;
    while (c != EOF)
    {
    c =fputc(c, fptr2);//placing value in output file
        i++;
        c = fgetc(fptr1);//reading value from input file
        if((i>=start)&&(i<=finish))
        {
        	if(((i-54)%4==0))
        	{
        		c=0;//setting blue color channel to zero
			}
		}
    }

	fclose(fptr1);//closing the file
    fclose(fptr2);
}

int main(){
	Manipulation();
}

