
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define BMP_CHECK_OFFSET 0x0000
#define DATA_OFFSET_OFFSET 0x000A
#define WIDTH_OFFSET 0x0012
#define HEIGHT_OFFSET 0x0016
#define FILLESIZE_OFFSET 0x0002
#define BITS_PER_PIXEL_OFFSET 0x001C
#define HEADER_SIZE 14
#define INFO_HEADER_SIZE 40
#define BITMAP_SIZE 1024
#define NO_COMPRESION 0
#define MAX_NUMBER_OF_COLORS 0
#define ALL_COLORS_REQUIRED 0

typedef unsigned int int32;
typedef short int16;
typedef unsigned char byte;

void BMPcheck(char header[3],int32 width, int32 height,int32 bytesPerPixel,int32 FileSize,int32 dataOffset) //function for checking BMP file
{
   if (!strcmp(header,"BM")) //comparing first two bytes of image with "BM"
        {   printf("Read the BMP file successfully\n");     //print info about image if image is BMP image
            printf("Height = %u pixels\nWidth = %u pixels\nBytes per pixel = %u KB\n",height,width,bytesPerPixel);
            printf("Size of Image = %u KB\nSize of Data Offset = %u KB\n\n",FileSize/1024,dataOffset);
        }
   else {
            printf("Image is not a BMP file"); //print if image is not BMP
        }

}

void grayscaleImage(byte **pixels, int32 *width, int32 *height, int32 *bytesPerPixel,byte **newpixels)
{
        int temp = *bytesPerPixel;
        if(temp==1)
        {
            printf("Image is already grayscale");
            exit(1);
        }
        int paddedRowSize = (int)(4 * ceil((float)(*width) / 4.0f))*(*bytesPerPixel); //for padded bytes
        int unpaddedRowSize = (*width)*(*bytesPerPixel);
        int totalSize = unpaddedRowSize*(*height);
        *newpixels = (byte*)malloc(totalSize); //allocating dynamic memory to pixel data
        int32 x;
        for(int i=0;i<*height;i++){
            for(int j=0;j<*width;j++){
    x=(int)(*(*pixels+temp*i*(*width)+j*temp)*0.1+*(*pixels+temp*i*(*width)+j*temp+1)*0.6+*(*pixels+temp*i*(*width)+j*temp+2)*0.3); //weighted grayscale Y=0.3R+0.6G+0.1B
        *(*newpixels+temp*i*(*width)+j*temp)=x;//allocating resultant value in B
    *(*newpixels+temp*i*(*width)+j*temp+1)=x; //allocating resultant value in G
    *(*newpixels+temp*i*(*width)+j*temp+2)=x; //allocating resultant value in R
    }
}
}

void Rot45Image(byte **pixels, int32 *width, int32 *height, int32 *bytesPerPixel,byte **newpixels)
{
        int unpaddedRowSize = (*width)*(*bytesPerPixel*2);
        int totalSize = unpaddedRowSize*(*height*2);
        *newpixels = (byte*)malloc(totalSize); //location for storing rotated pixels of enlarged image
        byte *temp = (byte*)malloc(totalSize); //temporary location for storing pixel data
        double xt;
        double yt;
        double sinx = 0.7;  // degrees
        double cosx = 0.7;
        int32 xCenter = *height/2;        // Rotate original image by its center.
        int32 yCenter = *width/2;

if(*bytesPerPixel==1){
         for(int i=1;i<=*height*2;i++)
        {
            for(int j=1;j<=*width*2;j++){
                *(temp+(i-1)*(*width*2)+(j-1))=255; //allocating 255 to all pixels
                *(*newpixels+(i-1)*(*width*2)+(j-1))=255; //allocating 255 to all pixels
            }
            }

    for(int i=1;i<=*height;i++)
        {
            for(int j=1;j<=*width;j++){
               *(temp+(*height/2 +i-1)*(*width*2)+(*width/2 +j-1))=*(*pixels+(i-1)*(*width)+(j-1)); //matching centers of original and new image and placing pixels accordingly
            }
            }

for(int x=*height/2; x<=*height*1.5; x++) {
    xt = x - xCenter;
    double xt_cosx = xt*cosx;
    double xt_sinx = xt*sinx;
    for(int y=*width/2; y<=*width*1.5; y++) {
        yt = y - yCenter;
        long xRotate = lround(xt_cosx - (yt*sinx))+*height; //center changed due to rotation of center
        long yRotate = lround((yt*cosx) + xt_sinx)+*width*0.3;
  if( (xRotate >= 0) && (xRotate <= *height*2) && (yRotate >= 0) && (yRotate <= *width*2) ){
          *(*newpixels+(xRotate-1)*(*width*2)+(yRotate-1))=*(temp+(x-1)*(*width*2)+(y-1));//assigning rotated pixel values
        }
    }
}
}
else if(*bytesPerPixel==3)
{
     for(int i=1;i<=*height*2;i++)
        {
            for(int j=1;j<=*width*2;j++){
                *(temp+(i-1)*(*width*2*3)+(j*3))=255;  //allocating 255 to all pixels of B
                *(temp+(i-1)*(*width*2*3)+(j*3)-1)=255; //allocating 255 to all pixels of G
                *(temp+(i-1)*(*width*2*3)+(j*3)-2)=255; //allocating 255 to all pixels of R
                *(*newpixels+(i-1)*(*width*2*3)+(j*3))=255; //allocating 255 to all pixels of B
                *(*newpixels+(i-1)*(*width*2*3)+(j*3)-1)=255; //allocating 255 to all pixels of G
                *(*newpixels+(i-1)*(*width*2*3)+(j*3)-2)=255; //allocating 255 to all pixels of R
            }
            }
for(int i=1;i<=*height;i++)
        {
            for(int j=1;j<=*width;j++){
               *(temp+(*height/2 +i-2)*(*width*2*3)+((*width/2 +j)*3))=*(*pixels+(i-1)*(*width*3)+(j*3)); //matching centers of original and new image and placing pixels of B
               *(temp+(*height/2 +i-2)*(*width*2*3)+((*width/2 +j)*3)-1)=*(*pixels+(i-1)*(*width*3)+(j*3)-1); //matching centers of original and new image and placing pixels of G
               *(temp+(*height/2 +i-2)*(*width*2*3)+((*width/2 +j)*3)-2)=*(*pixels+(i-1)*(*width*3)+(j*3)-2); //matching centers of original and new image and placing pixels of R
            }
for(int x=*height/2; x<=*height*1.5; x++) {
    xt = x - xCenter;
    double xt_cosx = xt*cosx;
    double xt_sinx = xt*sinx;
    for(int y=*width/2; y<=*width*1.5; y++) {
        yt = y - yCenter;
        long xRotate = lround(xt_cosx - (yt*sinx))+*height;
        long yRotate = lround((yt*cosx) + xt_sinx)+*width*0.3;
  if( (xRotate >= 0) && (xRotate <= *height*2) && (yRotate >= 0) && (yRotate <= *width*2) ){
          *(*newpixels+((xRotate-1))*(*width*2*3)+(yRotate*3))=*(temp+(x-1)*(*width*2*3)+(y*3)); //assigning rotated pixel values to B
          *(*newpixels+((xRotate-1))*(*width*2*3)+(yRotate*3)-1)=*(temp+(x-1)*(*width*2*3)+(y*3-1)); //assigning rotated pixel values to G
          *(*newpixels+((xRotate-1))*(*width*2*3)+(yRotate*3)-2)=*(temp+(x-1)*(*width*2*3)+(y*3-2)); //assigning rotated pixel values to R
        }
    }
}
}
  *height=*height*2;
   *width=*width*2;
}
}

void NinetyImage(byte **pixels, int32 *width, int32 *height, int32 *bytesPerPixel,byte **newpixels)
{
        int paddedRowSize = (int)(4 * ceil((float)(*width) / 4.0f))*(*bytesPerPixel);
        int unpaddedRowSize = (*width)*(*bytesPerPixel);
        int totalSize = unpaddedRowSize*(*height);
        *newpixels = (byte*)malloc(totalSize);
if (*bytesPerPixel==3){
    for(int i=1;i<*height+1;i++)
        {
            for(int j=1;j<*width+1;j++){
                *(*newpixels+3*(*height-i)*(*width)+((*width-j+1)*3)-1)=*(*pixels+3*(j-1)*(*width)+(i*3)-1); //taking transpose of pixel of R
                *(*newpixels+3*(*height-i)*(*width)+((*width-j+1)*3)-2)=*(*pixels+3*(j-1)*(*width)+(i*3)-2); //taking transpose of pixel of G
                *(*newpixels+3*(*height-i)*(*width)+((*width-j+1)*3)-3)=*(*pixels+3*(j-1)*(*width)+(i*3)-3); //taking transpose of pixel of B
    }
    }
}
else if (*bytesPerPixel==1){
    for(int i=1;i<*height+1;i++)
        {
            for(int j=0;j<*width;j++){
                *(*newpixels+(*height-i)*(*width)+(*width-j)-1)=*(*pixels+(j)*(*width)+i-1); //taking transpose of pixel of grayscale
            }}}

byte x;
if (*bytesPerPixel==3){
for(int i=1;i<*height+1;i++)
        {
            for(int j=1;j<*width/2;j++){
               x=*(*newpixels+3*(i)*(*width)+((*width-j+1)*3)-1);  //flipping entire row of color pixel R
               *(*newpixels+3*(i-1)*(*width)+((*width-j+1)*3)-1)=*(*newpixels+3*(i-1)*(*width)+(j*3)-1);
               *(*newpixels+3*(i-1)*(*width)+(j*3)-1)=x;
               x=*(*newpixels+3*(i)*(*width)+((*width-j+1)*3)-2); //flipping entire row of color pixel G
               *(*newpixels+3*(i-1)*(*width)+((*width-j+1)*3)-2)=*(*newpixels+3*(i-1)*(*width)+(j*3)-2);
               *(*newpixels+3*(i-1)*(*width)+(j*3)-2)=x;
               x=*(*newpixels+3*(i)*(*width)+((*width-j+1)*3)-3); //flipping entire row of color pixel B
               *(*newpixels+3*(i-1)*(*width)+((*width-j+1)*3)-3)=*(*newpixels+3*(i-1)*(*width)+(j*3)-3);
               *(*newpixels+3*(i-1)*(*width)+(j*3)-3)=x;
    }
    }
}
else if (*bytesPerPixel==1){
        for(int i=1;i<*height+1;i++)
        {
            for(int j=0;j<*width/2;j++){
               x=*(*newpixels+(i-1)*(*width)+(*width-j)-1); //flipping entire row of grayscale
               *(*newpixels+(i-1)*(*width)+(*width-j)-1)=*(*newpixels+(i-1)*(*width)+j);
               *(*newpixels+(i-1)*(*width)+j)=x;
            }
        }
}
}

void DflipImage(byte **pixels, int32 *width, int32 *height, int32 *bytesPerPixel,byte **newpixels)
{
        int paddedRowSize = (int)(4 * ceil((float)(*width) / 4.0f))*(*bytesPerPixel);
        int unpaddedRowSize = (*width)*(*bytesPerPixel);
        int totalSize = unpaddedRowSize*(*height);
        *newpixels = (byte*)malloc(totalSize);
if (*bytesPerPixel==3){
    for(int i=1;i<*height+1;i++)
        {
            for(int j=1;j<*width+1;j++){
                *(*newpixels+3*(*height-i)*(*width)+((*width-j+1)*3)-1)=*(*pixels+3*(j-1)*(*width)+(i*3)-1); //taking transpose of pixel R
                *(*newpixels+3*(*height-i)*(*width)+((*width-j+1)*3)-2)=*(*pixels+3*(j-1)*(*width)+(i*3)-2); //taking transpose of pixel G
                *(*newpixels+3*(*height-i)*(*width)+((*width-j+1)*3)-3)=*(*pixels+3*(j-1)*(*width)+(i*3)-3); //taking transpose of pixel B
    }
    }
}
else if (*bytesPerPixel==1){
    for(int i=1;i<*height+1;i++)
        {
            for(int j=0;j<*width;j++){
                *(*newpixels+(*height-i)*(*width)+(*width-j)-1)=*(*pixels+(j)*(*width)+i-1); //taking transpose of pixel of grayscale
            }}}
}

void scaleImage(byte **pixels, int32 *width, int32 *height, int32 *bytesPerPixel,byte **newpixels,int Sx,int Sy)
{
        int unpaddedRowSize = (*width)*(*bytesPerPixel*Sx);
        int totalSize = unpaddedRowSize*(*height*Sy);
        *newpixels = (byte*)malloc(totalSize); //allocating memory for scaled image

if(*bytesPerPixel==1){
         for(int i=1;i<=*height;i++)
        {
            for(int j=1;j<=*width;j++){
                *(*newpixels+(i-1)*(*width*Sy*Sx)+((j-1)*Sx))=*(*pixels+(i-1)*(*width)+(j-1));//allocating values to scaled image
            }
            }

for(int i=1;i<=*height*Sy;i++)
        {
            for(int j=1;j<=*width*Sx;){
               for(int t=1;t<Sx;t++){
                *(*newpixels+(i-1)*(*width*Sx)+(j+t-1))=*(*newpixels+(i-1)*(*width*Sx)+(j-1));//row interpolation
                    }
                j=j+Sx;//skip columns by scaling factor no.
            }
            }
 for(int i=1;i<=(*height-1)*Sy;)
        {
            for(int j=1;j<=*width*Sx;j++){
                    for(int t=1;t<Sy;t++){
                *(*newpixels+(i+t-1)*(*width*Sx)+j)=*(*newpixels+((i-1))*(*width*Sx)+j);//column interpolation
                    }
            }
            i=i+Sy; //skip columns by scaling factor no.
            }
}
else if(*bytesPerPixel==3)
{
     for(int i=1;i<=*height;i++)
        {
            for(int j=1;j<=*width;j++){

                *(*newpixels+(i-1)*(*width*Sy*Sx*3)+(j*Sx*3))=*(*pixels+(i-1)*(*width*3)+(j*3)); //allocating values to scaled image to pixel B
                *(*newpixels+(i-1)*(*width*Sy*Sx*3)+(j*Sx*3)-1)=*(*pixels+(i-1)*(*width*3)+(j*3)-1);//allocating values to scaled image to pixel G
                *(*newpixels+(i-1)*(*width*Sy*Sx*3)+(j*Sx*3)-2)=*(*pixels+(i-1)*(*width*3)+(j*3)-2);//allocating values to scaled image to pixel R
            }
            }

for(int i=1;i<=*height*Sy;i++)
        {
            for(int j=1;j<=*width*Sx;){
               for(int t=1;t<Sx;t++){
                *(*newpixels+(i-1)*(*width*Sx*3)+((j+t-1)*3))=*(*newpixels+((i-1))*(*width*Sx*3)+((j-1)*3));  //row interpolation of pixel of B
                *(*newpixels+(i-1)*(*width*Sx*3)+((j+t-1)*3)-1)=*(*newpixels+((i-1))*(*width*Sx*3)+((j-1)*3)-1);//row interpolation of pixel of G
                *(*newpixels+(i-1)*(*width*Sx*3)+((j+t-1)*3)-2)=*(*newpixels+((i-1))*(*width*Sx*3)+((j-1)*3)-2);//row interpolation of pixel of R
                    }
                j=j+Sx;
            }
            }
 for(int i=1;i<=(*height-1)*Sy;)
        {
            for(int j=0;j<=*width*Sx;j++){
                    for(int t=1;t<Sy;t++){
                *(*newpixels+(i+t-1)*(*width*Sx*3)+(j*3))=*(*newpixels+(i-1)*(*width*Sx*3)+(j*3)); //column interpolation of pixel B
                *(*newpixels+(i+t-1)*(*width*Sx*3)+(j*3)-1)=*(*newpixels+(i-1)*(*width*Sx*3)+(j*3)-1); //column interpolation of pixel G
                *(*newpixels+(i+t-1)*(*width*Sx*3)+(j*3)-2)=*(*newpixels+(i-1)*(*width*Sx*3)+(j*3)-2); //column interpolation of pixel R
                    }
            }
            i=i+Sy;
            }

}
  *height=*height*Sy; //scaling height accordingly
   *width=*width*Sx; //scaling width accordingly
}


void ReadImage(const char *fileName,byte **pixels, int32 *width, int32 *height, int32 *bytesPerPixel,int32 *FileSize,int32 *dataOffset,char *header[3],int32 colorpallete[256])
{
        FILE *imageFile = fopen(fileName, "rb");
        fseek(imageFile, BMP_CHECK_OFFSET, SEEK_SET); //setting offset for header
        fread(header, 2, 1, imageFile); //reading first two header bytes of image
        fseek(imageFile, DATA_OFFSET_OFFSET, SEEK_SET); //setting offset for data offset
        fread(dataOffset, 4, 1, imageFile);//reading data offset of image
        fseek(imageFile, WIDTH_OFFSET, SEEK_SET);//setting offset for width
        fread(width, 4, 1, imageFile);//read width of image
        fseek(imageFile, HEIGHT_OFFSET, SEEK_SET);//setting offset for height
        fread(height, 4, 1, imageFile);//read height of image
        fseek(imageFile, FILLESIZE_OFFSET, SEEK_SET);//setting offset for filesize
        fread(FileSize, 4, 1, imageFile);//read file size of image
        int16 bitsPerPixel;
        fseek(imageFile, BITS_PER_PIXEL_OFFSET, SEEK_SET);
        fread(&bitsPerPixel, 2, 1, imageFile); //reading bits per pixel of image
        *bytesPerPixel = ((int32)bitsPerPixel) / 8;//calculating bytes per pixel
       if(*bytesPerPixel==1)//reading only for 8bit images
        {
            fseek(imageFile,0x0036, SEEK_SET); //setting offset for BITMAP
            fread(colorpallete,4,256, imageFile); //reading BITMAP of image
        }
        int paddedRowSize = (int)(4 * ceil((float)(*width) / 4.0f))*(*bytesPerPixel);
        int unpaddedRowSize = (*width)*(*bytesPerPixel);
        int totalSize = unpaddedRowSize*(*height);
        *pixels = (byte*)malloc(totalSize); //allocating memory for pixel data of input image
        int i = 0;
        byte *currentRowPointer = *pixels+((*height-1)*unpaddedRowSize);
        for (i = 0; i < *height; i++)
        {
                fseek(imageFile, *dataOffset+(i*paddedRowSize), SEEK_SET);//taking offset to last row
            fread(currentRowPointer, 1, unpaddedRowSize, imageFile); //reading pixel data row-wise
            currentRowPointer -= unpaddedRowSize;//decreasing row by one
        }
        fclose(imageFile);//close file
}

void WriteImage(const char *fileName, byte *pixels, int32 width, int32 height,int32 bytesPerPixel,int32 f,int32 colorpallete[256])
{
        FILE *outputFile = fopen(fileName, "wb");
        const char *BM = "BM";
        fwrite(&BM[0], 1, 1, outputFile); //writing first byte to "B"
        fwrite(&BM[1], 1, 1, outputFile); //writing second byte to "M"
        int paddedRowSize = (int)(4 * ceil((float)width/4.0f))*bytesPerPixel;//calculating file size
        int32 fileSize;
        if(bytesPerPixel == 1)
        {fileSize = paddedRowSize*height + HEADER_SIZE + INFO_HEADER_SIZE + BITMAP_SIZE;//file size for 8bit image
        }
        else
        {
        fileSize = paddedRowSize*height + HEADER_SIZE + INFO_HEADER_SIZE;//file size for RGB colored image
        }
        fwrite(&fileSize, 4, 1, outputFile);//writing file size to output image
        int32 reserved = 0x0000;
        fwrite(&reserved, 4, 1, outputFile);
        int32 dataOffset=f; //data Offset value
        fwrite(&dataOffset, 4, 1, outputFile); //writing data offset value to output image
        int32 infoHeaderSize = INFO_HEADER_SIZE;
        fwrite(&infoHeaderSize, 4, 1, outputFile);
        fwrite(&width, 4, 1, outputFile);//writing width to output image
        fwrite(&height, 4, 1, outputFile);//writing height to output image
        int16 planes = 1; //always 1
        fwrite(&planes, 2, 1, outputFile);
        int16 bitsPerPixel = bytesPerPixel * 8;
        fwrite(&bitsPerPixel, 2, 1, outputFile);//writing bytes per pixel to output imagw
        int32 compression = NO_COMPRESION;
        fwrite(&compression, 4, 1, outputFile);
        int32 imageSize = width*height*bytesPerPixel;
        fwrite(&imageSize, 4, 1, outputFile); //writing pixel data size to output image
        int32 resolutionX = 11811; //300 dpi
        int32 resolutionY = 11811; //300 dpi
        fwrite(&resolutionX, 4, 1, outputFile);//writing resolution of outputimage
        fwrite(&resolutionY, 4, 1, outputFile);
        int32 colorsUsed = MAX_NUMBER_OF_COLORS;
        fwrite(&colorsUsed, 4, 1, outputFile);
        int32 importantColors = ALL_COLORS_REQUIRED;
        fwrite(&importantColors, 4, 1, outputFile);
        if(bytesPerPixel==1)//assigning only for 8bit images
        {
        fwrite(&colorpallete,4,256, outputFile);//writing Bitmap to output image
        }
        int i = 0;
        int unpaddedRowSize = width*bytesPerPixel;
        for ( i = 0; i < height; i++)
        {
                int pixelOffset = ((height - i) - 1)*unpaddedRowSize;//taking offset to last row and then decreasing by one
                fwrite(&pixels[pixelOffset], 1, paddedRowSize, outputFile); //writing pixel data row-wise
        }
        fclose(outputFile);//close file
}

int main()
{
        byte *pixels;
        byte *newpixels;
        int32 width;
        int32 height;
        int32 bytesPerPixel;
        int32 FileSize;
        int32 dataOffset;
        int32  colorpallete[256];
        int Sx=2;//width scaling factor
        int Sy=3;//height scaling factor
        char header[3];
      ReadImage("lena_colored_256.bmp", &pixels, &width, &height,&bytesPerPixel,&FileSize,&dataOffset,&header,&colorpallete);
        //**REMOVE COMMENT FOR PERFORMING SPECIFIC OPERATION**//
        grayscaleImage(&pixels,&width,&height,&bytesPerPixel,&newpixels);
       //DflipImage(&pixels,&width,&height,&bytesPerPixel,&newpixels);
        //Rot45Image(&pixels,&width,&height,&bytesPerPixel,&newpixels);
        //NinetyImage(&pixels,&width,&height,&bytesPerPixel,&newpixels);
        //scaleImage(&pixels,&width,&height,&bytesPerPixel,&newpixels,Sx,Sy);
        BMPcheck(header, width, height, bytesPerPixel,FileSize,dataOffset);
        WriteImage("lena2x3.bmp", newpixels, width, height, bytesPerPixel,dataOffset,colorpallete);
        free(pixels); //freeing allocated memory
        free(newpixels);
        return 0;
}
